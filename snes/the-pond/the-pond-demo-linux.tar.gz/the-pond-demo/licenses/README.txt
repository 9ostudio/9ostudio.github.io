This game is a Super Nintendo program. It runs in the player next to this
folder, which is made of:

  - the player (GPL version 3, licenses/GPL-3.0.txt), our own small front end;
  - bsnes (GPL version 3, licenses/bsnes-LICENSE.txt), the emulator, in its
    libretro version (https://github.com/libretro/bsnes);
  - SDL2 (zlib licence, licenses/SDL2-zlib.txt) for the window, sound and
    controllers (on Linux, the copy in the Steam Runtime).

The complete source of the player and of bsnes, as built here, is in the
source/ folder next to this one.

The game itself (the .sfc file) is a separate work and is not covered by the
GPL; all rights reserved.
