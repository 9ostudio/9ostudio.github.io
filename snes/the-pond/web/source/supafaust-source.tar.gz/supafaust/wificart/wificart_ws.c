#include "wificart_net.h"

#include <emscripten/emscripten.h>
#include <emscripten/websocket.h>
#include <stdio.h>
#include <string.h>

enum { IN_SIZE = 65536 };

static EMSCRIPTEN_WEBSOCKET_T ws = 0;
static int state = WNET_NONE;
static const char *why = "";
static uint8_t in[IN_SIZE];
static int in_length;

EM_JS(int, wnet_page_https, (void), {
    return typeof location !== 'undefined' && location.protocol === 'https:' ? 1 : 0;
});

static void fail(const char *reason)
{
    if (ws)
    {
        emscripten_websocket_close(ws, 1000, "");
        emscripten_websocket_delete(ws);
    }
    ws = 0;
    state = WNET_FAILED;
    why = reason;
}

static EM_BOOL on_open(int type, const EmscriptenWebSocketOpenEvent *e, void *user)
{
    (void)type, (void)user;
    if (e->socket == ws)
        state = WNET_ONLINE;
    return EM_TRUE;
}

static EM_BOOL on_message(int type, const EmscriptenWebSocketMessageEvent *e, void *user)
{
    (void)type, (void)user;
    if (e->socket != ws || e->isText)
        return EM_TRUE;
    if (in_length + (int)e->numBytes > IN_SIZE)
        fail("queue full (the game does not read its messages)");
    else
    {
        memcpy(in + in_length, e->data, e->numBytes);
        in_length += e->numBytes;
    }
    return EM_TRUE;
}

static EM_BOOL on_close(int type, const EmscriptenWebSocketCloseEvent *e, void *user)
{
    (void)type, (void)user;
    if (e->socket == ws)
        fail(state == WNET_CONNECTING ? "connection refused" : "closed by the server");
    return EM_TRUE;
}

static EM_BOOL on_error(int type, const EmscriptenWebSocketErrorEvent *e, void *user)
{
    (void)type, (void)user;
    if (e->socket == ws)
        fail(state == WNET_CONNECTING ? "connection refused" : "connection lost");
    return EM_TRUE;
}

void wnet_close(void)
{
    if (ws)
    {
        emscripten_websocket_close(ws, 1000, "");
        emscripten_websocket_delete(ws);
    }
    ws = 0;
    state = WNET_NONE;
    in_length = 0;
}

int wnet_open(const char *host, const char *port, const char **reason)
{
    EmscriptenWebSocketCreateAttributes attributes;
    char url[320];

    wnet_close();
    if (!emscripten_websocket_is_supported())
    {
        *reason = "no WebSocket in this browser";
        return -1;
    }
    snprintf(url, sizeof url, "%s://%s:%s/", wnet_page_https() ? "wss" : "ws", host, port);
    emscripten_websocket_init_create_attributes(&attributes);
    attributes.url = url;
    attributes.protocols = NULL;
    ws = emscripten_websocket_new(&attributes);
    if (ws <= 0)
    {
        ws = 0;
        *reason = "bad address";
        return -1;
    }
    emscripten_websocket_set_onopen_callback(ws, NULL, on_open);
    emscripten_websocket_set_onmessage_callback(ws, NULL, on_message);
    emscripten_websocket_set_onclose_callback(ws, NULL, on_close);
    emscripten_websocket_set_onerror_callback(ws, NULL, on_error);
    state = WNET_CONNECTING;
    in_length = 0;
    return 0;
}

int wnet_state(void)
{
    return state;
}

const char *wnet_error(void)
{
    return why;
}

int wnet_send(const uint8_t *data, int len)
{
    if (state != WNET_ONLINE)
        return 0;
    if (emscripten_websocket_send_binary(ws, (void *)data, len) != EMSCRIPTEN_RESULT_SUCCESS)
    {
        fail("connection lost");
        return -1;
    }
    return len;
}

int wnet_recv(uint8_t *buf, int max)
{
    int n = in_length < max ? in_length : max;

    if (state == WNET_FAILED)
        return -1;
    if (n <= 0)
        return 0;
    memcpy(buf, in, n);
    memmove(in, in + n, in_length - n);
    in_length -= n;
    return n;
}
