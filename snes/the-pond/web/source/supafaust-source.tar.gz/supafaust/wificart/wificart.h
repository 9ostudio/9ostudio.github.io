#ifndef WIFICART_H
#define WIFICART_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int wificart_enabled(void);
void wificart_power(void);
void wificart_unload(void);
uint8_t wificart_read(unsigned addr, uint8_t open_bus);
void wificart_write(unsigned addr, uint8_t data);

#ifdef __cplusplus
}
#endif

#endif
