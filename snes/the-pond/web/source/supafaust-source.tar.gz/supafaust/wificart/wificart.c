#include "wificart.h"
#include "wificart_net.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    RX_READY = 0x01, TX_BUSY = 0x02, WIFI = 0x04, ONLINE = 0x08,
    CONNECTING = 0x10, ERROR_BIT = 0x20, SETUP_BIT = 0x40, READY = 0x80
};
enum { CMD_SEND = 0x01, CMD_CONNECT = 0x02, CMD_DISCONNECT = 0x03, CMD_SETUP = 0x04 };
enum { QUEUE = 64, IN_SIZE = 4096, OUT_SIZE = 16384 };

static uint8_t rx[256], tx[256];
static uint8_t rx_length, length;
static int rx_ready, tx_busy_reads, rx_wait_reads;
static int connected, error, logging, no_network;
static uint8_t in[IN_SIZE];
static int in_length;
static uint8_t out[OUT_SIZE];
static int out_length;
static uint8_t queue[QUEUE][256];
static int queue_first, queue_count;
enum { PROXY_NONE, PROXY_ASK, PROXY_WAIT };
static int proxy;
static char proxy_target[256];

static void say(const char *format, ...)
{
    va_list list;

    if (!logging)
        return;
    va_start(list, format);
    fprintf(stderr, "wificart: ");
    vfprintf(stderr, format, list);
    fprintf(stderr, "\n");
    va_end(list);
}

static int env_on(const char *name)
{
    const char *value = getenv(name);
    return value && *value && strcmp(value, "0") != 0;
}

int wificart_enabled(void)
{
    static int enabled = -1;

    if (enabled < 0)
    {
        const char *value = getenv("WIFICART");
        enabled = !value || strcmp(value, "0") != 0;
    }
    return enabled;
}

static void disconnect(const char *why)
{
    wnet_close();
    if (why)
        say("connection ended: %s", why);
    error = why != NULL;
    connected = 0;
    proxy = PROXY_NONE;
    in_length = out_length = 0;
    queue_first = queue_count = 0;
    rx_ready = 0;
}

void wificart_power(void)
{
    logging = env_on("WIFICART_LOG");
    no_network = env_on("WIFICART_SETUP");
    wnet_close();
    memset(rx, 0, sizeof rx);
    memset(tx, 0, sizeof tx);
    rx_length = length = 0;
    rx_ready = tx_busy_reads = rx_wait_reads = 0;
    connected = error = 0;
    proxy = PROXY_NONE;
    in_length = out_length = 0;
    queue_first = queue_count = 0;
}

void wificart_unload(void)
{
    wnet_close();
}

static void parse(void)
{
    int at = 0;

    while (in_length - at >= 2)
    {
        int size = in[at] << 8 | in[at + 1];
        uint8_t *message;

        if (size == 0 || size > 255)
        {
            disconnect("bad message length from the server");
            return;
        }
        if (in_length - at < 2 + size)
            break;
        if (queue_count == QUEUE)
        {
            disconnect("queue full (the game does not read its messages)");
            return;
        }
        message = queue[(queue_first + queue_count++) % QUEUE];
        message[0] = (uint8_t)size;
        memcpy(message + 1, in + at + 2, size);
        at += 2 + size;
    }
    memmove(in, in + at, in_length - at);
    in_length -= at;
}

static int proxy_answer(void)
{
    int at;

    for (at = 0; at + 3 < in_length; at++)
        if (!memcmp(in + at, "\r\n\r\n", 4))
            break;
    if (at + 3 >= in_length)
        return in_length > 2048 ? -1 : 0;
    if (in_length < 12 || memcmp(in, "HTTP/1.", 7) || memcmp(in + 8, " 200", 4))
        return -1;
    memmove(in, in + at + 4, in_length - at - 4);
    in_length -= at + 4;
    return 1;
}

static void poll_net(void)
{
    int state = wnet_state();

    if (state == WNET_NONE)
        return;
    if (state == WNET_FAILED)
    {
        disconnect(wnet_error());
        return;
    }
    if (state == WNET_CONNECTING)
        return;
    if (proxy == PROXY_ASK)
    {
        out_length = snprintf((char *)out, OUT_SIZE, "CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n",
                              proxy_target, proxy_target);
        proxy = PROXY_WAIT;
    }
    if (!connected && proxy == PROXY_NONE)
    {
        connected = 1;
        say("online");
    }
    while (out_length)
    {
        int sent = wnet_send(out, out_length);
        if (sent < 0)
        {
            disconnect("connection lost");
            return;
        }
        if (sent == 0)
            break;
        memmove(out, out + sent, out_length - sent);
        out_length -= sent;
    }
    for (;;)
    {
        int got = wnet_recv(in + in_length, IN_SIZE - in_length);
        if (got < 0)
        {
            disconnect(wnet_error());
            return;
        }
        if (got == 0)
            break;
        in_length += got;
        if (proxy == PROXY_WAIT)
        {
            int answer = proxy_answer();
            if (answer < 0)
            {
                disconnect("the proxy refused the server");
                return;
            }
            if (answer == 0)
                continue;
            proxy = PROXY_NONE;
            connected = 1;
            say("online (through the proxy)");
        }
        parse();
        if (!connected)
            return;
    }
}

static void connect_to(const char *where, int size)
{
    char address[256];
    const char *server = getenv("WIFICART_SERVER");
    const char *through = getenv("WIFICART_PROXY");
    const char *why = NULL;
    char *colon;

    if (server && *server)
        snprintf(address, sizeof address, "%s", server);
    else
    {
        memcpy(address, where, size);
        address[size] = 0;
    }
    disconnect(NULL);
    error = 0;
    say("CONNECT %s", address);
    if (no_network)
    {
        disconnect("no WiFi network");
        return;
    }
    colon = strrchr(address, ':');
    if (!colon)
    {
        disconnect("no port in the address");
        return;
    }
    if (through && *through)
    {
        snprintf(proxy_target, sizeof proxy_target, "%s", address);
        snprintf(address, sizeof address, "%s", through);
        colon = strrchr(address, ':');
        if (!colon)
        {
            disconnect("no port in the proxy's address");
            return;
        }
    }
    *colon = 0;
    if (wnet_open(address, colon + 1, &why) != 0)
        disconnect(why);
    else if (through && *through)
        proxy = PROXY_ASK;
}

static void command(uint8_t cmd)
{
    switch (cmd)
    {
    case CMD_SEND:
        if (!connected || !length)
        {
            say("SEND of %u bytes while offline (ignored)", (unsigned)length);
            return;
        }
        if (out_length + 2 + length > OUT_SIZE)
        {
            disconnect("the server does not take messages");
            return;
        }
        out[out_length++] = 0;
        out[out_length++] = length;
        memcpy(out + out_length, tx, length);
        out_length += length;
        poll_net();
        break;
    case CMD_CONNECT:
        connect_to((const char *)tx, length);
        break;
    case CMD_DISCONNECT:
        say("DISCONNECT");
        disconnect(NULL);
        break;
    case CMD_SETUP:
        say("SETUP (the emulated WiFi uses the computer's network)");
        break;
    default:
        say("unknown command %02x (ignored)", (unsigned)cmd);
    }
}

static uint8_t status(void)
{
    uint8_t value = READY | (no_network ? SETUP_BIT : WIFI);

    poll_net();
    if (!rx_ready && !rx_wait_reads && queue_count)
    {
        uint8_t *message = queue[queue_first];
        rx_length = message[0];
        memcpy(rx, message + 1, rx_length);
        queue_first = (queue_first + 1) % QUEUE;
        queue_count--;
        rx_ready = 1;
    }
    if (rx_ready)
        value |= RX_READY;
    if (tx_busy_reads)
        value |= TX_BUSY;
    if (connected)
        value |= ONLINE;
    if (wnet_state() == WNET_CONNECTING || proxy != PROXY_NONE)
        value |= CONNECTING;
    if (error)
        value |= ERROR_BIT;
    if (tx_busy_reads)
        tx_busy_reads--;
    if (rx_wait_reads)
        rx_wait_reads--;
    return value;
}

uint8_t wificart_read(unsigned addr, uint8_t open_bus)
{
    (void)open_bus;
    addr &= 0x3ff;
    if (addr < 0x100)
        return rx[addr];
    if (addr < 0x200)
        return tx[addr - 0x100];
    switch (addr)
    {
    case 0x200: return 'W';
    case 0x201: return 'I';
    case 0x202: return 'F';
    case 0x203: return 'I';
    case 0x204: return 0x01;
    case 0x205: return status();
    case 0x206: return rx_length;
    case 0x208: return length;
    }
    return 0x00;
}

void wificart_write(unsigned addr, uint8_t data)
{
    addr &= 0x3ff;
    if (addr >= 0x100 && addr < 0x200)
    {
        if (tx_busy_reads)
            say("TX written while TX_BUSY (ignored)");
        else
            tx[addr - 0x100] = data;
        return;
    }
    switch (addr)
    {
    case 0x207:
        rx_ready = 0;
        rx_wait_reads = 1;
        break;
    case 0x208:
        if (tx_busy_reads)
            say("LEN written while TX_BUSY (ignored)");
        else
            length = data;
        break;
    case 0x209:
        if (tx_busy_reads)
            say("CMD %02x written while TX_BUSY (ignored)", (unsigned)data);
        else
        {
            tx_busy_reads = 1;
            command(data);
        }
        break;
    }
}
