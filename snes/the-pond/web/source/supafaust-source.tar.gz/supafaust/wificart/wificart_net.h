#ifndef WIFICART_NET_H
#define WIFICART_NET_H

#include <stdint.h>

enum { WNET_NONE, WNET_CONNECTING, WNET_ONLINE, WNET_FAILED };

int wnet_open(const char *host, const char *port, const char **why);
int wnet_state(void);
const char *wnet_error(void);
int wnet_send(const uint8_t *data, int len);
int wnet_recv(uint8_t *buf, int max);
void wnet_close(void);

#endif
