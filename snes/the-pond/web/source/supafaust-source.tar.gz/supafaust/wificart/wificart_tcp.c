#include "wificart_net.h"

#include <string.h>
#if defined(_WIN32)
  #include <winsock2.h>
  #include <ws2tcpip.h>
  typedef SOCKET wsock;
  #define NO_SOCKET INVALID_SOCKET
  #define SEND_FLAGS 0
#else
  #include <errno.h>
  #include <fcntl.h>
  #include <netdb.h>
  #include <netinet/in.h>
  #include <netinet/tcp.h>
  #include <sys/select.h>
  #include <sys/socket.h>
  #include <sys/types.h>
  #include <unistd.h>
  typedef int wsock;
  #define NO_SOCKET (-1)
  #if defined(MSG_NOSIGNAL)
    #define SEND_FLAGS MSG_NOSIGNAL
  #else
    #define SEND_FLAGS 0
  #endif
#endif

static wsock sock = NO_SOCKET;
static int state = WNET_NONE;
static const char *why = "";

static int would_block(void)
{
#if defined(_WIN32)
    int e = WSAGetLastError();
    return e == WSAEWOULDBLOCK || e == WSAEINPROGRESS;
#else
    return errno == EWOULDBLOCK || errno == EAGAIN || errno == EINPROGRESS;
#endif
}

static void fail(const char *reason)
{
    wnet_close();
    state = WNET_FAILED;
    why = reason;
}

void wnet_close(void)
{
    if (sock != NO_SOCKET)
    {
#if defined(_WIN32)
        closesocket(sock);
#else
        close(sock);
#endif
    }
    sock = NO_SOCKET;
    state = WNET_NONE;
}

int wnet_open(const char *host, const char *port, const char **reason)
{
    struct addrinfo hints, *found = NULL;
    int on = 1, result;

    wnet_close();
#if defined(_WIN32)
    {
        static int started = 0;
        WSADATA data;
        if (!started)
            WSAStartup(MAKEWORD(2, 2), &data);
        started = 1;
    }
#endif
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &found) != 0 || !found)
    {
        *reason = "unknown host";
        return -1;
    }
    sock = socket(found->ai_family, found->ai_socktype, found->ai_protocol);
    if (sock == NO_SOCKET)
    {
        freeaddrinfo(found);
        *reason = "no socket";
        return -1;
    }
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof on);
#if defined(SO_NOSIGPIPE)
    setsockopt(sock, SOL_SOCKET, SO_NOSIGPIPE, (const char *)&on, sizeof on);
#endif
#if defined(_WIN32)
    {
        u_long nb = 1;
        ioctlsocket(sock, FIONBIO, &nb);
    }
#else
    fcntl(sock, F_SETFL, fcntl(sock, F_GETFL, 0) | O_NONBLOCK);
#endif
    result = connect(sock, found->ai_addr, (int)found->ai_addrlen);
    freeaddrinfo(found);
    if (result == 0)
        state = WNET_ONLINE;
    else if (would_block())
        state = WNET_CONNECTING;
    else
    {
        wnet_close();
        *reason = "connection refused";
        return -1;
    }
    return 0;
}

int wnet_state(void)
{
    fd_set writable, failed;
    struct timeval now = {0, 0};
    int problem = 0;
#if defined(_WIN32)
    int size = sizeof problem;
#else
    socklen_t size = sizeof problem;
#endif

    if (state != WNET_CONNECTING)
        return state;
    FD_ZERO(&writable);
    FD_ZERO(&failed);
    FD_SET(sock, &writable);
    FD_SET(sock, &failed);
    if (select((int)sock + 1, NULL, &writable, &failed, &now) <= 0)
        return state;
    getsockopt(sock, SOL_SOCKET, SO_ERROR, (char *)&problem, &size);
    if (problem || FD_ISSET(sock, &failed) || !FD_ISSET(sock, &writable))
        fail("connection refused");
    else
        state = WNET_ONLINE;
    return state;
}

const char *wnet_error(void)
{
    return why;
}

int wnet_send(const uint8_t *data, int len)
{
    int sent = (int)send(sock, (const char *)data, len, SEND_FLAGS);

    if (sent > 0)
        return sent;
    if (sent < 0 && would_block())
        return 0;
    fail("connection lost");
    return -1;
}

int wnet_recv(uint8_t *buf, int max)
{
    int got;

    if (max <= 0)
        return 0;
    got = (int)recv(sock, (char *)buf, max, 0);
    if (got > 0)
        return got;
    if (got < 0 && would_block())
        return 0;
    fail(got == 0 ? "closed by the server" : "connection lost");
    return -1;
}
