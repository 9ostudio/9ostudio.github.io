/******************************************************************************/
/* Mednafen - Multi-system Emulator                                           */
/******************************************************************************/
/* DSPUtility.h:
**  Copyright (C) 2018 Mednafen Team
**
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software Foundation, Inc.,
** 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef __MDFN_SOUND_DSPUTILITY_H
#define __MDFN_SOUND_DSPUTILITY_H

namespace Mednafen
{

namespace DSPUtility
{

void generate_kaiser_sinc_lp(double* coeffs, unsigned num_coeffs, double tb_center, double alpha);
void normalize(double* coeffs, unsigned num_coeffs, double v = 1.0);

}

}
#endif

