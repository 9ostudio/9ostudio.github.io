#include <mednafen/mednafen.h>
