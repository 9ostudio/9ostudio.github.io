#ifndef __MDFN_SNES_FAUST_WIFICART_GLUE_H
#define __MDFN_SNES_FAUST_WIFICART_GLUE_H

namespace MDFN_IEN_SNES_FAUST
{
void WIFICART_Init(void) MDFN_COLD;
void WIFICART_Reset(bool powering_up) MDFN_COLD;
void WIFICART_Kill(void) MDFN_COLD;
}

#endif
