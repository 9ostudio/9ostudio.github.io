#include "snes.h"
#include "wificart_glue.h"
#include "../../wificart/wificart.h"

namespace MDFN_IEN_SNES_FAUST
{

static DEFREAD(WIFICART_Read)
{
 if(MDFN_LIKELY(!DBG_InHLRead))
  CPUM.timestamp += MEMCYC_FAST;

 return wificart_read(A, CPUM.mdr);
}

static DEFWRITE(WIFICART_Write)
{
 CPUM.timestamp += MEMCYC_FAST;
 wificart_write(A, V);
}

void WIFICART_Init(void)
{
 if(!wificart_enabled())
  return;

 for(unsigned bank = 0x00; bank < 0x100; bank++)
 {
  if(bank <= 0x3F || (bank >= 0x80 && bank <= 0xBF))
   Set_A_Handlers((bank << 16) | 0x5000, (bank << 16) | 0x53FF, WIFICART_Read, WIFICART_Write);
 }
}

void WIFICART_Reset(bool powering_up)
{
 wificart_power();
}

void WIFICART_Kill(void)
{
 wificart_unload();
}

}
