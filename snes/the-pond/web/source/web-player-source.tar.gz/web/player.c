/* Copyright (C) 2026 9ostudio. GPLv3 (see steam/player/LICENSE). */
#include <emscripten.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libretro.h"

#define GAME_PATH "/game.sfc"

static const struct { const char *key, *value; } options[] = {
    { "supafaust_renderer", "st" },
    { "supafaust_thread_affinity_emu", "0x0" },
    { "supafaust_thread_affinity_ppu", "0x0" },
    { "supafaust_pixel_format", "xrgb8888" },
    { "supafaust_correct_aspect", "disabled" },
    { "supafaust_audio_rate", "48000" },
};

static int test_mode, test_frames, test_shot_at = -1, test_fps = 60;
static const char *test_shot;
static unsigned frame_no;

static unsigned char *rgba;
static unsigned rgba_w, rgba_h;

EM_JS(void, show_frame, (const unsigned char *pixels, int w, int h), {
    if (typeof document === 'undefined')
        return;
    var canvas = Module.canvas;
    if (canvas.width != w || canvas.height != h) {
        canvas.width = w;
        canvas.height = h;
        Module.fitCanvas && Module.fitCanvas();
    }
    if (!Module.ctx2d)
        Module.ctx2d = canvas.getContext('2d');
    if (!Module.image || Module.image.width != w || Module.image.height != h)
        Module.image = Module.ctx2d.createImageData(w, h);
    Module.image.data.set(HEAPU8.subarray(pixels, pixels + w * h * 4));
    Module.ctx2d.putImageData(Module.image, 0, 0);
});

EM_JS(void, save_frame, (const unsigned char *pixels, int w, int h, const char *path), {
    require('fs').writeFileSync(UTF8ToString(path), HEAPU8.subarray(pixels, pixels + w * h * 4));
    console.log('frame ' + w + 'x' + h + ' saved to ' + UTF8ToString(path));
});

static void video_cb(const void *data, unsigned w, unsigned h, size_t pitch)
{
    unsigned x, y;

    if (!data)
        return;
    if (w != rgba_w || h != rgba_h || !rgba)
    {
        free(rgba);
        rgba = malloc((size_t)w * h * 4);
        rgba_w = w;
        rgba_h = h;
    }
    for (y = 0; y < h; y++)
    {
        const unsigned *src = (const unsigned *)((const unsigned char *)data + y * pitch);
        unsigned char *dst = rgba + (size_t)y * w * 4;

        for (x = 0; x < w; x++, dst += 4)
        {
            unsigned p = src[x];
            dst[0] = p >> 16;
            dst[1] = p >> 8;
            dst[2] = p;
            dst[3] = 255;
        }
    }
    if (!test_mode)
        show_frame(rgba, w, h);
}

#define AUDIO_MAX 4096
static float audio_l[AUDIO_MAX], audio_r[AUDIO_MAX];
static int audio_n;

static size_t audio_batch_cb(const int16_t *data, size_t frames)
{
    size_t i;

    for (i = 0; i < frames && audio_n < AUDIO_MAX; i++, audio_n++)
    {
        audio_l[audio_n] = data[i * 2] / 32768.0f;
        audio_r[audio_n] = data[i * 2 + 1] / 32768.0f;
    }
    return frames;
}

static void audio_sample_cb(int16_t l, int16_t r)
{
    int16_t s[2] = { l, r };
    audio_batch_cb(s, 1);
}

EM_JS(void, play_sound, (const float *left, const float *right, int n, int rate), {
    var ctx = Module.audio;
    if (!ctx || ctx.state != 'running' || n <= 0)
        return;
    var buffer = ctx.createBuffer(2, n, rate);
    buffer.copyToChannel(HEAPF32.subarray(left >> 2, (left >> 2) + n), 0);
    buffer.copyToChannel(HEAPF32.subarray(right >> 2, (right >> 2) + n), 1);
    var now = ctx.currentTime;
    if (!Module.soundAt || Module.soundAt < now + 0.02 || Module.soundAt > now + 0.2)
        Module.soundAt = now + 0.06;
    var source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(Module.soundAt);
    Module.soundAt += n / rate;
});

EM_JS(int, pad_bits, (void), {
    var bits = Module.keyBits ? Module.keyBits() : 0;
    var pads = [];
    if (!Module.noPads && typeof navigator !== 'undefined' && navigator.getGamepads) {
        try {
            pads = navigator.getGamepads() || [];
        } catch (e) {
            Module.noPads = true;
        }
    }

    var map = [[0, 0], [1, 8], [2, 1], [3, 9], [4, 10], [5, 11], [8, 2], [9, 3],
               [12, 4], [13, 5], [14, 6], [15, 7]];
    for (var p = 0; p < pads.length; p++) {
        var pad = pads[p];
        if (!pad || !pad.connected)
            continue;
        for (var i = 0; i < map.length; i++)
            if (pad.buttons[map[i][0]] && pad.buttons[map[i][0]].pressed)
                bits |= 1 << map[i][1];
        if (pad.axes.length >= 2) {
            if (pad.axes[0] < -0.5) bits |= 1 << 6;
            if (pad.axes[0] > 0.5) bits |= 1 << 7;
            if (pad.axes[1] < -0.5) bits |= 1 << 4;
            if (pad.axes[1] > 0.5) bits |= 1 << 5;
        }
    }
    return bits;
});

static int pad;
static struct { int from, to, id; } script[64];
static int script_n;

static void input_poll_cb(void) {}

static int16_t input_state_cb(unsigned port, unsigned device, unsigned index, unsigned id)
{
    (void)index;
    if (port || device != RETRO_DEVICE_JOYPAD || id >= 16)
        return 0;
    return (pad >> id) & 1;
}

static void input_read(void)
{
    int i;

    if (!test_mode)
        pad = pad_bits();
    else
        for (pad = 0, i = 0; i < script_n; i++)
            if ((int)frame_no >= script[i].from && (int)frame_no <= script[i].to)
                pad |= 1 << script[i].id;
    if ((pad & (1 << 6)) && (pad & (1 << 7)))
        pad &= ~(1 << 7);
    if ((pad & (1 << 4)) && (pad & (1 << 5)))
        pad &= ~(1 << 5);
}

static void parse_script(const char *spec)
{
    static const char *names[] = { "b", "y", "select", "start", "up", "down", "left", "right",
                                   "a", "x", "l", "r" };
    char buf[1024], *item, *save = NULL;

    snprintf(buf, sizeof buf, "%s", spec);
    for (item = strtok_r(buf, ",", &save); item; item = strtok_r(NULL, ",", &save))
    {
        int from, to;
        char *colon = strchr(item, ':'), *button, *save2 = NULL;

        if (!colon)
            continue;
        *colon = 0;
        if (sscanf(item, "%d-%d", &from, &to) != 2)
        {
            from = atoi(item);
            to = from + 3;
        }
        for (button = strtok_r(colon + 1, "+", &save2); button; button = strtok_r(NULL, "+", &save2))
        {
            unsigned i;
            for (i = 0; i < sizeof names / sizeof names[0]; i++)
                if (!strcmp(button, names[i]) && script_n < 64)
                {
                    script[script_n].from = from;
                    script[script_n].to = to;
                    script[script_n++].id = i;
                }
        }
    }
}

int sem_trywait(void *sem);

int pthread_getaffinity_np(unsigned long thread, unsigned long size, void *set)
{
    (void)thread, (void)size, (void)set;
    return 38;
}

int pthread_setaffinity_np(unsigned long thread, unsigned long size, const void *set)
{
    (void)thread, (void)size, (void)set;
    return 38;
}

int sem_timedwait(void *sem, const void *until)
{
    (void)until;
    return sem_trywait(sem);
}

static enum retro_pixel_format pixel_format;
static double fps = 60.0988, sample_rate = 48000;

static bool environment_cb(unsigned cmd, void *data)
{
    switch (cmd & 0xFFFF)
    {
    case RETRO_ENVIRONMENT_GET_VARIABLE:
    {
        struct retro_variable *var = data;
        unsigned i;
        for (i = 0; i < sizeof options / sizeof options[0]; i++)
            if (!strcmp(var->key, options[i].key))
            {
                var->value = options[i].value;
                return true;
            }
        return false;
    }
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        pixel_format = *(enum retro_pixel_format *)data;
        return pixel_format == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *(const char **)data = "/";
        return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE:
        *(bool *)data = true;
        return true;
    }
    return false;
}

static void frame(void)
{
    input_read();
    retro_run();
    play_sound(audio_l, audio_r, audio_n, (int)sample_rate);
    audio_n = 0;
    frame_no++;
}

EM_JS(double, now_ms, (void), { return performance.now(); });
EM_JS(int, page_hidden, (void), { return typeof document !== 'undefined' && document.hidden ? 1 : 0; });

static double clock_start;
static unsigned clock_frames;

static void refresh(void)
{
    double due;
    int n = 0;

    if (page_hidden())
    {
        clock_start = 0;
        return;
    }
    if (!clock_start)
    {
        clock_start = now_ms();
        clock_frames = 0;
    }
    due = (now_ms() - clock_start) * fps / 1000.0;
    while (clock_frames < due && n < 3)
    {
        frame();
        clock_frames++;
        n++;
    }
    if (clock_frames + 3 < due)
    {
        clock_start = now_ms();
        clock_frames = 0;
    }
}

EM_JS(void, node_exit, (int code), { process.exit(code); });

static void test_tick(void)
{
    frame();
    if ((int)frame_no - 1 == test_shot_at && test_shot && rgba)
        save_frame(rgba, rgba_w, rgba_h, test_shot);
    if ((int)frame_no >= test_frames)
    {
        emscripten_cancel_main_loop();
        retro_unload_game();
        retro_deinit();
        node_exit(0);
    }
}

EM_JS(int, in_node, (void), { return typeof document === 'undefined' ? 1 : 0; });

int main(int argc, char **argv)
{
    struct retro_game_info game = { GAME_PATH, NULL, 0, NULL };
    struct retro_system_av_info av;
    FILE *f;
    int i;

    test_mode = in_node();
    for (i = 1; i + 1 < argc; i += 2)
    {
        if (!strcmp(argv[i], "--frames"))
            test_frames = atoi(argv[i + 1]);
        else if (!strcmp(argv[i], "--shot"))
            test_shot = argv[i + 1];
        else if (!strcmp(argv[i], "--input"))
            parse_script(argv[i + 1]);
        else if (!strcmp(argv[i], "--fps"))
            test_fps = atoi(argv[i + 1]);
    }
    if (test_mode && !test_frames)
        test_frames = 600;
    test_shot_at = test_frames - 1;

    f = fopen(GAME_PATH, "rb");
    if (!f)
    {
        printf("no ROM at %s\n", GAME_PATH);
        return 1;
    }
    fseek(f, 0, SEEK_END);
    game.size = ftell(f);
    fseek(f, 0, SEEK_SET);
    game.data = malloc(game.size);
    if (fread((void *)game.data, 1, game.size, f) != game.size)
        return 1;
    fclose(f);

    retro_set_environment(environment_cb);
    retro_set_video_refresh(video_cb);
    retro_set_audio_sample(audio_sample_cb);
    retro_set_audio_sample_batch(audio_batch_cb);
    retro_set_input_poll(input_poll_cb);
    retro_set_input_state(input_state_cb);
    retro_init();
    if (!retro_load_game(&game))
    {
        printf("the core refused the ROM\n");
        return 1;
    }
    retro_set_controller_port_device(0, RETRO_DEVICE_JOYPAD);
    retro_get_system_av_info(&av);
    if (av.timing.fps > 0)
        fps = av.timing.fps;
    if (av.timing.sample_rate > 0)
        sample_rate = av.timing.sample_rate;

    if (test_mode)
        emscripten_set_main_loop(test_tick, test_fps, 0);
    else
        emscripten_set_main_loop(refresh, 0, 0);
    return 0;
}
