#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
GAME_DIR=$(cd "${GAME_DIR:-$ROOT/..}" && pwd)
[ -f "$GAME_DIR/Makefile" ] || { echo "no game in $GAME_DIR: run it from a game repo (engine/ inside it) or set GAME_DIR" >&2; exit 1; }
var() { sed -n "s/^$1 *:= *//p" "$GAME_DIR/Makefile" | head -1; }
GAME=${GAME:-$(var GAME)}
GAME=${GAME:-$(basename "$GAME_DIR")}
TITLE=${TITLE:-$(var TITLE)}
TITLE=${TITLE:-$GAME}
ROM=$(var ROMNAME)
ROM=${ROM:-$GAME}
WEB=$ROOT/web
OUT=$WEB/out
JOBS=$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)

emsdk() {
    if ! command -v emcc >/dev/null; then
        source "${EMSDK:-$HOME/.local/opt/emsdk}/emsdk_env.sh" >/dev/null 2>&1
    fi
}

step_core() {
    local src=${1:?supafaust checkout} copy=$OUT/supafaust
    emsdk
    rm -rf "$copy"
    mkdir -p "$OUT/core"
    cp -R "$src" "$copy"
    (cd "$copy" && git clean -qfdx 2>/dev/null; git checkout -q -- . 2>/dev/null || true)
    mkdir -p "$copy/wificart"
    cp "$ROOT"/cart/emu/*.[ch] "$copy/wificart/"
    cp "$ROOT"/cart/supafaust/wificart_glue.* "$copy/mednafen/snes_faust/"
    if command -v patch >/dev/null; then
        patch -p1 -s -d "$copy" < "$ROOT/cart/supafaust/supafaust.patch"
    else
        git -C "$copy" apply "$ROOT/cart/supafaust/supafaust.patch"
    fi
    emmake make -C "$copy" platform=emscripten NO_GCC=1 -j"$JOBS"
    cp "$copy/mednafen_supafaust_libretro_emscripten.bc" "$OUT/core/supafaust.a"
    cp "$copy/COPYING" "$OUT/core/supafaust-COPYING.txt"
    tar czf "$OUT/core/supafaust-source.tar.gz" --exclude=.git --exclude='*.o' --exclude='*.bc' \
        -C "$OUT" supafaust
}

step_page() {
    local rom=${ROM_FILE:-$ROOT/steam/out/rom/$ROM.sfc} dst=$OUT/$GAME
    emsdk
    [ -n "${ROM_FILE:-}" ] || GAME=$GAME GAME_DIR=$GAME_DIR "$ROOT/steam/build.sh" rom
    rm -rf "$dst"
    mkdir -p "$dst"
    sed "s|<title>Game</title>|<title>$TITLE</title>|" "$WEB/shell.html" > "$OUT/shell.html"
    emcc -O2 -c "$WEB/player.c" -I"$ROOT/steam/player" -o "$OUT/player.o"
    em++ -O2 "$OUT/player.o" "$OUT/core/supafaust.a" \
        -o "$dst/index.html" --shell-file "$OUT/shell.html" \
        --embed-file "$rom@/game.sfc" --pre-js "$WEB/pre.js" -lwebsocket.js \
        -sALLOW_MEMORY_GROWTH=1 -sENVIRONMENT=web,node
    mkdir -p "$dst/source"
    cp "$OUT/core/supafaust-COPYING.txt" "$dst/source/"
    cp "$OUT/core/supafaust-source.tar.gz" "$dst/source/"
    tar czf "$dst/source/web-player-source.tar.gz" -C "$ROOT" web/player.c web/shell.html web/pre.js web/build.sh \
        steam/player/libretro.h steam/player/LICENSE cart
    ls -la "$dst"
}

step_test() {
    emsdk
    node "$OUT/$GAME/index.js" --frames "${FRAMES:-600}" --shot "$OUT/test.rgba" \
        --input "${INPUT:-80:a}"
    python3 - "$OUT/test.rgba" <<'EOF'
import sys
data = open(sys.argv[1], "rb").read()
lit = sum(1 for i in range(0, len(data), 4) if data[i] | data[i + 1] | data[i + 2])
print("lit pixels:", lit)
sys.exit(0 if lit > 1000 else 1)
EOF
}

case ${1:-} in
core) step_core "${2:-}" ;;
page) step_page ;;
test) step_test ;;
*) echo "usage: engine/web/build.sh core <supafaust checkout> | page | test   (TYPE; GAME_DIR, GAME, TITLE; ROM_FILE: embed this ROM instead of building one)"; exit 1 ;;
esac
