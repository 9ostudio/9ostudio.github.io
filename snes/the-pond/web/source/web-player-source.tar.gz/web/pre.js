Module.preRun = Module.preRun || [];
Module.preRun.push(function () {
  if (typeof location !== 'undefined' && typeof URLSearchParams !== 'undefined') {
    var page = new URLSearchParams(location.search);
    if (page.get('server'))
      ENV.WIFICART_SERVER = page.get('server');
    if (page.get('log'))
      ENV.WIFICART_LOG = '1';
  } else if (typeof process !== 'undefined' && process.env) {
    for (var name in process.env)
      if (name.indexOf('WIFICART') == 0)
        ENV[name] = process.env[name];
  }
});
