# WiFi cartridge: specification, revision 1

A SNES cartridge that holds the game and a WiFi chip. The game exchanges
**messages** (1 to 255 bytes each) with one server; the cartridge does
everything else: joining the WiFi network, DNS, the TCP connection. The SNES
sees a 1 KB window: a receive buffer, a send buffer and a few registers.

This document is the contract between the game (src/engine/online/online_asm.asm), the
emulated cartridge (cart/bsnes) and the real one. A change to anything the
SNES or the server can see is a new revision.

## 1. The window

Banks `$00-$3F` and `$80-$BF`, addresses `$5000-$53FF` (A-bus, `/ROMSEL`
high). Nothing in the console answers there, so a plain cartridge reads back
open bus.

| Address | Name | Access | |
|---|---|---|---|
| `$5000-$50FF` | RX | read | the message received (`RX_LEN` bytes) |
| `$5100-$51FF` | TX | read/write | the message or command argument to send |
| `$5200-$5203` | ID | read | `"WIFI"` (`$57 $49 $46 $49`) |
| `$5204` | REVISION | read | `$01` |
| `$5205` | STATUS | read | see 2 |
| `$5206` | RX_LEN | read | length of the message in RX, 1-255 (valid while `RX_READY`) |
| `$5207` | RX_NEXT | write | any value: the SNES is done with RX |
| `$5208` | LEN | read/write | length of the command's argument in TX, 0-255 |
| `$5209` | CMD | write | starts a command (see 3) |
| `$520A-$53FF` | | | reserved: read `$00`, writes ignored |

**Bus timing.** The CPU reaches this region at 6 master clocks per access
(about 280 ns), DMA at 8 (about 370 ns). The cartridge must answer reads and
take writes at that speed, every time, without wait states: the SNES cannot
wait. This is why the buffers sit in logic on the cartridge (see 7) and not in
the WiFi chip.

**Detecting the cartridge.** Read ID and REVISION. On a plain cartridge they
read as open bus (usually the high byte of the address just used, `$52`), so
`"WIFI"` never matches by chance.

## 2. STATUS (`$5205`)

| Bit | Name | Set while |
|---|---|---|
| 0 | RX_READY | a message waits in RX |
| 1 | TX_BUSY | the cartridge is still taking the last command: TX, LEN and CMD must not be written |
| 2 | WIFI | joined to a WiFi network |
| 3 | ONLINE | connected to the server |
| 4 | CONNECTING | a CONNECT is in progress |
| 5 | ERROR | the last CONNECT failed, or the connection was lost (cleared by the next CONNECT) |
| 6 | SETUP | the setup hotspot is open (see 5) |
| 7 | READY | the WiFi chip has started; 0 at power-on until then |

The SNES sends no command before READY.

## 3. Commands

Write the argument into TX and its length into LEN, then the command into CMD.
TX_BUSY is set at once by the write to CMD and stays set until the cartridge
has taken the command (TX may then be written again). The status bits a
command changes (CONNECTING, ONLINE, ERROR) are only meaningful once TX_BUSY
has cleared: until then they may still describe the previous command.

| CMD | Name | Argument in TX | |
|---|---|---|---|
| `$01` | SEND | the message, LEN 1-255 | send it to the server as one message; ignored unless ONLINE |
| `$02` | CONNECT | `host:port` in ASCII, e.g. `play.example.com:5800` | drop any connection, then connect: CONNECTING, then ONLINE or ERROR (at once without WIFI) |
| `$03` | DISCONNECT | none | close the connection |
| `$04` | SETUP | none | open the setup hotspot (5) |

Other values are ignored (TX_BUSY still clears).

## 4. Receiving

1. Wait for RX_READY.
2. Read RX_LEN bytes from RX (CPU reads or DMA).
3. Write RX_NEXT. RX_READY drops at once; the next message (if any) arrives in
   RX and RX_READY rises again.

The cartridge keeps messages from the server in order and queues them while RX
is full: at least 64 messages. If the queue overflows, it closes the connection
(ERROR) rather than drop messages silently. When the connection ends, the
messages not read yet are dropped with it (RX_READY clears).

## 5. WiFi setup

The cartridge remembers its network. At power-on it joins it by itself (WIFI).
Without one, or after the SETUP command, it opens a hotspot named
`SNES-WIFI-xxxx` (`xxxx`: the end of its MAC address, also printed on the
label). A phone that joins it gets a page to choose the network and type the
password. Once joined, the hotspot closes (SETUP clears, WIFI sets). The game
only shows instructions; nothing is typed on the SNES.

## 6. Cartridge ↔ server

One TCP connection, Nagle off (`TCP_NODELAY`). Each message travels as a
2-byte big-endian length, then its bytes, in both directions. The cartridge
adds nothing else and reads nothing into the messages: their content belongs to
the game and its server. A message from the server longer than 255 bytes, or
of length 0, is a protocol error: the cartridge closes the connection (ERROR).

Revision 1 has no TLS: games must not send anything secret.

## 7. Inside the cartridge (suggested, not binding)

- **Bus logic** (FPGA or CPLD with RAM): decodes the window, holds RX and TX
  as dual-port RAM and the registers, answers at bus speed (1).
- **WiFi chip** (an ESP32): WiFi, DNS, TCP, the queue (4), the setup hotspot
  (5). It talks to the bus logic over SPI: fills RX and sets RX_READY when RX is
  free, reads TX and clears TX_BUSY after a command.
- **Targets:** after RX_NEXT, the next queued message in RX within 1 ms;
  TX_BUSY clear within 1 ms of a command. The game polls once per frame
  (16.7 ms).
- **Levels and power:** the console bus is 5 V, the WiFi chip 3.3 V. The chip
  draws a few hundred mA while transmitting, from the console's 5 V: measure it
  on a real console.
- **Game ROM:** flash, so the WiFi chip can rewrite it later (updates, in a
  later revision), 120 ns or faster (FastROM). A CIC clone for the lockout.
- **Save RAM:** 5 V FRAM, 8 KB or more (fallback: 8 KB SRAM with a battery), at the standard LoROM place
  (banks `$70-$7D`/`$F0-$FF`, `$0000-$7FFF`); see `BOARD.md`.
  It is outside the window and changes nothing the window shows (REV stays 1).
- **`/IRQ`:** unused in revision 1 (leave it released).

## 8. Emulation

`cart/emu` is this cartridge emulated in plain C, for every emulator build we
ship: bsnes (`cart/bsnes`, the Steam player and the test tools; `steam/build.sh
core` patches it in) and Supafaust (`cart/supafaust`: the web and the Classic
minis; snes9x's licence forbids commercial use). In a browser the connection is
a WebSocket carrying the same byte stream (the server takes both on one
port).
It is always present there. The emulated WiFi is joined (unless `WIFICART_SETUP=1`); the TCP
connection is real. Like the real chip, the emulated one takes a moment: the
first STATUS read after a command still shows TX_BUSY, and after RX_NEXT the
next message shows one STATUS read later. A game that skips a wait fails in
the emulator too. Environment variables:

| Variable | |
|---|---|
| `WIFICART=0` | no WiFi cartridge (a plain cartridge: open bus) |
| `WIFICART_SERVER=host:port` | connect there, whatever the game asks |
| `WIFICART_PROXY=host:port` | by way of an HTTP proxy (`CONNECT`): the minis' hub, `mini/hub` |
| `WIFICART_SETUP=1` | a cartridge with no network saved: SETUP, never WIFI |
| `WIFICART_LOG=1` | log commands and connection events to stderr |
