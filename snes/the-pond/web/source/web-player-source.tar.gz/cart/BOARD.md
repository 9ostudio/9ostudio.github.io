# The cartridge: what to ask the manufacturer

One cartridge for every game: a LoROM, FastROM board with save memory (FRAM) and
the WiFi chip of `SPEC.md`. WiFi brings game updates and, later, online modes such
as versus; a game that doesn't use it yet simply never reads the WiFi window.
Every game is a 128 KB (1 Mbit) image today.

## The order, in one line

LoROM, 1A3B-style, FRAM save (5 V parallel, at least 8 KB, standard LoROM save
address), CIC clone (NTSC + PAL), flash game ROM of 4 Mbit or larger at 120 ns or
faster, plus an ESP32 WiFi chip and a CPLD/FPGA bus logic answering the WiFi window
of `SPEC.md` revision 1 (banks `$00-$3F`/`$80-$BF`, `$5000-$53FF`), 5 V to 3.3 V
level shifting, a 3.3 V regulator sized for the ESP32's transmit peaks, an antenna
placed so the shell doesn't block it, no coprocessor, shell for the market.

The board is designed from `SPEC.md` by our electronics team; the manufacturer
builds it from their files.

## In detail

| | |
|---|---|
| Layout | LoROM, 1A3B-style (Nintendo's SHVC-1A3B: LoROM with 64 Kbit save RAM), with FRAM instead of SRAM and battery |
| Game ROM | **Flash**, so the WiFi chip can rewrite it (updates). **120 ns or faster** (the games use FastROM), e.g. SST39SF0x0A parts (45-70 ns). **4 Mbit (512 KB) or more**: room for games to grow, and for an update to be written beside the running game and switched to only once it is complete and checked, so a power cut during an update can't leave a broken cartridge. Smaller images are mirrored or padded. |
| Save memory | **FRAM**: 5 V parallel, 8 KB (64 Kbit) or more (larger parts such as 32 KB are fine; games use the first 8 KB), 120 ns or faster, no battery. The save chip is disabled while the console's power rises or falls or it resets. Fallback: 8 KB SRAM with a CR2032 battery and the same protection. |
| Save address | the standard LoROM place: banks `$70-$7D` and `$F0-$FF`, addresses `$0000-$7FFF` (a chip of 8 KB repeats across that range) |
| WiFi | the window of `SPEC.md` (banks `$00-$3F`/`$80-$BF`, `$5000-$53FF`) answered by the bus logic, with an ESP32 behind it (WiFi, TCP, the setup hotspot, writing updates to the flash). The window and the save memory never overlap. |
| Power and levels | the console bus is 5 V, the ESP32 3.3 V: level shifting on every line between them, and a 3.3 V regulator for the ESP32's transmit peaks (a few hundred mA from the console's 5 V; measure it on a real console) |
| Antenna | where the plastic shell and the console don't block it (chip antenna or PCB trace at the top edge) |
| Lockout | a CIC clone that boots on NTSC and PAL consoles (or the region's CIC) |
| Shell | the shape for the market: SNES (North America) or Super Famicom / PAL |
| Coprocessor | none |

## The ROM header

What the console and emulators read at `$7FD5-$7FD9` of each ROM:

| Byte | Today | Once a game saves |
|---|---|---|
| Map mode | `$30` (LoROM, FastROM) | `$30` |
| Cartridge type | `$00` (ROM only) | `$02` (ROM, RAM, battery: the standard code for save memory that survives power-off, FRAM included) |
| ROM size | `$07` (1 Mbit) | `$07` |
| RAM size | `$00` | `$03` (8 KB) |
| Region | `$01` (North America) | `$01` |

The board doesn't depend on the header: a game that doesn't save never touches the
save memory, and a game finds the WiFi chip by reading `WIFI` at `$5200`.
Emulators, flash carts and our players follow the header, so it changes together
with the first game that saves.

## Checking a sample board

- Each game boots on a real NTSC console (and a PAL one if the CIC allows).
- A long session (30 minutes or more) shows no glitches or crashes: a ROM slower
  than 120 ns shows up here first.
- WiFi: the setup hotspot appears on first power-on; once a network is entered,
  tinymancer shows "Online" against a test server, and the current while
  transmitting stays within what the console's 5 V can give.
- Save memory: a test ROM writes a pattern, the console is switched off for a day,
  and the pattern is still there; power cycles in a row don't change it.
