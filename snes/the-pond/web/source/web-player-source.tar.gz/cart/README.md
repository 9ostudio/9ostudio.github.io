# The WiFi cartridge

A SNES cartridge with WiFi, so a game can reach a server. It is the one cartridge
every game ships on (`BOARD.md`): WiFi brings updates and, later, online modes such
as versus. tinymancer uses it today for a small online world where players see
each other walk in the house.

| | |
|---|---|
| `BOARD.md` | what to ask the manufacturer: the one cartridge for every game (ROM, save memory, WiFi, lockout, header) |
| `SPEC.md` | what the SNES and the server see: the contract the hardware must meet |
| `emu/` | the cartridge emulated, in plain C, for every emulator build we ship |
| `bsnes/` | its hooks in bsnes (the Steam player, the test tools) |
| `supafaust/` | its hooks in Supafaust, Mednafen's fast SNES core (GPLv2+; the web player `web/`, the Classic minis `mini/`) |

The game side is in `src/engine/online/` (driver and the other players); the
server is `tinymancer/server/`.

## Status

- **Revision 1** of the spec. Emulated, with a game and a server using it.
- **Hardware:** to be built (the electronics team). Section 7 of the spec
  suggests a design; only what the SNES and the server see is binding.
- **Later revisions:** TLS to the server, game updates written to the flash
  over WiFi, `/IRQ` when a message arrives.

## The server as a service

`tinymancer/server/tinymancer.service` runs the server under systemd: Python 3
only, port 5800, a throwaway sandboxed user, restarted if it stops, started at
boot. It runs on the home server (192.168.4.245, a Raspberry Pi 3 on Ubuntu 22.04):

```sh
sudo install -D -m 644 tinymancer/server/server.py /opt/tinymancer/server.py
sudo install -m 644 tinymancer/server/tinymancer.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now tinymancer
journalctl -u tinymancer -f                  # who connects
```

## Trying it on one machine

```sh
python3 tinymancer/server/server.py          # the server, port 5800
python3 tinymancer/server/bots.py 3          # 3 fake players wandering the room
make -C tinymancer                           # the ROM (ONLINE := 1)
python3 src/tools/snesrun.py tinymancer/build/tinymancer.sfc --frames 900 \
    --shots 899 --out /tmp/shots --input "80:a"   # A skips the logo
```

The test tools (`snesrun.py`, `make shots`) use the bsnes core in
`~/.local/opt/libretro-src/bsnes`. `steam/build.sh core <that checkout>` adds the
cartridge to it, as CI does for the Steam builds. The emulated WiFi is always
joined; the connection to the server is real. `WIFICART_LOG=1` prints what the
cartridge does, and `WIFICART=0` emulates a plain cartridge.

## Trying a real cartridge

1. Run the server on a machine of the same network; note its address.
2. Set `ONLINE_SERVER` in `tinymancer/src/game_config.h` to that
   `address:5800` and build the ROM into the cartridge's flash.
3. On first power-on the cartridge has no network: it opens its setup hotspot
   (spec, 5) and the corner of the room says "WiFi setup". Join
   `SNES-WIFI-xxxx` from a phone and pick the network. Then the corner says
   "Connecting", then "Online 1", and the bots appear.
