#include <sfc/sfc.hpp>
#include "wificart.h"

namespace SuperFamicom {

WiFiCart wificart;

auto WiFiCart::enabled() -> bool { return wificart_enabled(); }
auto WiFiCart::unload() -> void { wificart_unload(); }
auto WiFiCart::power() -> void { wificart_power(); }
auto WiFiCart::read(uint addr, uint8 data) -> uint8 { return wificart_read(addr, data); }
auto WiFiCart::write(uint addr, uint8 data) -> void { wificart_write(addr, data); }

}
