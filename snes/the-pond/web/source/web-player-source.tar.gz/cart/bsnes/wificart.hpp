struct WiFiCart {
  static auto enabled() -> bool;

  auto unload() -> void;
  auto power() -> void;

  auto read(uint addr, uint8 data) -> uint8;
  auto write(uint addr, uint8 data) -> void;
};

extern WiFiCart wificart;
